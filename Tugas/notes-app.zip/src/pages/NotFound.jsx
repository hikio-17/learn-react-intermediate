import React from 'react'

function NotFound () {
  return (
    <h1 style={{ textAlign: 'center', color: 'white', marginTop: '100px' }}>
      Page Not Found
    </h1>
  )
}

export default NotFound
